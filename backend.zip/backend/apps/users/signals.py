from django.core.exceptions import ValidationError
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import ClientProfile, CustomUser, TrainerProfile


@receiver(post_save, sender=CustomUser)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        if instance.is_trainer:
            TrainerProfile.objects.create(user=instance)
        elif instance.is_client:
            ClientProfile.objects.create(user=instance)
